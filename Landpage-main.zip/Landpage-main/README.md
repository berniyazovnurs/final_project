# Landpage
Midterm : Kulmanov Zhanibek and Akhmet Miras;  id: 190107055 (Zhanibek) ,190103066(Miras); 
